# Modelo de tarefas (537)

| Task     | Tipo            | Período/Evento | Prioridade | Deadline             |
|----------|-----------------|----------------|------------|----------------------|
| alarm    | esporádica (evt)| notificação    | 5 (máx)    | latência do alarme   |
| sensor   | periódica       | 100 ms (10 Hz) | 4          | período              |
| detect   | esporádica (evt)| por amostra    | 3          | < período do sensor  |
| comm     | periódica       | 1000 ms        | 2          | soft                 |
| watchdog | periódica       | 2000 ms        | 1 (mín)    | soft                 |

## Conceitos exercitados
- **Escalonabilidade (RMA):** utilização total vs limite de Liu & Layland.
- **Jitter:** desvio do período real vs nominal (medido em `metrics/timing`).
- **Tempo de resposta:** fim-a-fim sensor→detect→alarm (latência do alarme).
- **Inversão de prioridade:** induzível segurando `mtx_state` na task comm durante
  um envio longo; comparar com/sem herança de prioridade (mutex do FreeRTOS).
- **Sobrecarga:** injetar carga/elevar frequências e medir deadline misses.
