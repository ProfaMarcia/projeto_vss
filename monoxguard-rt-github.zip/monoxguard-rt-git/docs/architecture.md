# Arquitetura — MonoxGuard-RT

Plataforma experimental de detecção de gás em tempo-real (ESP32 + FreeRTOS).
Foco acadêmico: comportamento temporal, concorrência e verificação formal.

## Camadas (separação proposital p/ verificação)
- **core/** — lógica PURA, sem dependência de hardware nem do RTOS. É o que se verifica
  com CBMC/ESBMC: `filter` (média móvel), `detection` (máquina de estados + histerese),
  `calib` (ADC→ppm).
- **hal/** — abstração de hardware: leitura do ADC, atuadores (LED/buzzer).
- **tasks/** — tasks do FreeRTOS que orquestram core + hal.
- **metrics/** — instrumentação temporal (período, jitter, deadline miss).

## Fluxo de dados
sensor → [fila q_samples] → detect → [snapshot g_reading + notificação] → alarm
                                          ↘ comm (telemetria CSV)

## IPC
- `q_samples` (queue): sensor → detect (amostra + timestamp).
- `xTaskNotify`: detect → alarm (mudança de estado; caminho rápido, baixa latência).
- `g_reading` + `mtx_state` (mutex): estado compartilhado; comm é o único leitor/impressor.
