# Demo no Wokwi
1. Crie um projeto ESP32 (Arduino) em wokwi.com.
2. Cole o firmware em `sketch.ino` (ou use o PlatformIO local com a extensão Wokwi).
3. Cole este `diagram.json` na aba do diagrama.
4. ▶ e gire o potenciômetro de gás (`pot_gas`, no `D34`): ao passar do limiar,
   o estado vira WARN/ALARM, o LED (`D4`) acende, o buzzer (`D13`) toca e o relé
   (`D14`, ativo-baixo) atua o exaustor.

## Pinos (alinhados ao `src/config.h`)
| Periférico            | Pino ESP32 | Observação                          |
|-----------------------|-----------|--------------------------------------|
| Sensor de gás (ADC)   | D34       | potenciômetro emula o MQ-7 (sem CO)  |
| LED de alarme         | D4        | via resistor 220Ω                    |
| Buzzer                | D13       |                                      |
| Relé (exaustor)       | D14       | módulo ativo em nível BAIXO          |
| Botão de MUTE (ISR)   | D27       | usa pull-up interno                  |
| DHT11/22 (DATA)       | D26       | peça Wokwi: `wokwi-dht22`            |
| LCD 16x2 (paralelo)   | RS19 EN23 D4=18 D5=17 D6=16 D7=25 | contraste em `pot_lcd` |

> O potenciômetro `pot_gas` substitui o sensor real — entrada analógica idêntica,
> sem CO. Para um detector de **monóxido**, o sensor físico correto é o **MQ-7**
> (o MQ-5 é para GLP/gás natural).

> Nota DHT: o Wokwi fornece a peça `wokwi-dht22`. A lib do projeto (DHTesp) cobre
> DHT11 e DHT22 — basta selecionar o tipo na inicialização.
