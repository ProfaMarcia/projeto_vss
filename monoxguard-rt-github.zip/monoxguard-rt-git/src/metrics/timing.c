#include "timing.h"
static uint64_t absdiff(uint64_t a, uint64_t b){ return a > b ? a - b : b - a; }

void timing_init(period_stats_t *s, uint64_t expected_us, uint64_t deadline_us){
    s->expected_us = expected_us; s->deadline_us = deadline_us;
    s->activations = 0; s->last_us = 0; s->have_last = 0;
    s->min_jitter_us = (uint64_t)-1; s->max_jitter_us = 0; s->sum_jitter_us = 0;
    s->deadline_misses = 0;
}

uint64_t timing_update(period_stats_t *s, uint64_t now_us){
    uint64_t jitter = 0;
    s->activations++;
    if (s->have_last){
        uint64_t period = now_us - s->last_us;
        jitter = absdiff(period, s->expected_us);
        if (jitter < s->min_jitter_us) s->min_jitter_us = jitter;
        if (jitter > s->max_jitter_us) s->max_jitter_us = jitter;
        s->sum_jitter_us += jitter;
        if (s->deadline_us && period > s->deadline_us) s->deadline_misses++;
    }
    s->last_us = now_us; s->have_last = 1;
    return jitter;
}
