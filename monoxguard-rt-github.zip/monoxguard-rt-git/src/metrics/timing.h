#ifndef TIMING_H
#define TIMING_H
#ifdef __cplusplus
extern "C" {
#endif
#include <stdint.h>

typedef struct {
    uint64_t expected_us;
    uint64_t deadline_us;     /* 0 = sem deadline */
    uint32_t activations;
    uint64_t last_us;
    uint8_t  have_last;
    uint64_t min_jitter_us, max_jitter_us, sum_jitter_us;
    uint32_t deadline_misses;
} period_stats_t;

void     timing_init(period_stats_t *s, uint64_t expected_us, uint64_t deadline_us);
uint64_t timing_update(period_stats_t *s, uint64_t now_us); /* retorna o jitter desta ativação */

#ifdef __cplusplus
}
#endif
#endif
