#ifndef SHARED_H
#define SHARED_H
#include <stdint.h>
#include "core/detection.h"   /* gas_state_t */

/* Elemento da fila sensor -> detect */
typedef struct {
    int32_t  raw;
    uint64_t ts_us;
} sample_t;

/* Snapshot compartilhado (protegido por mtx_state). Ponto unico de leitura. */
typedef struct {
    int32_t     raw;
    int32_t     ppm;
    gas_state_t state;
    uint64_t    ts_us;
    uint64_t    cross_us;          /* instante em que o estado subiu (borda)   */
    uint64_t    sensor_jitter_us;
    uint64_t    detect_jitter_us;
    uint64_t    alarm_latency_us;  /* cross_us -> atuacao                       */
    uint64_t    button_latency_us; /* ISR do botao -> task acordar (esporadico) */
    uint64_t    detect_exec_us;    /* tempo de execucao da task detect (atual)  */
    uint64_t    detect_exec_max_us;/* WCET observado (maximo) da task detect     */
    uint32_t    dropped_samples;
    int32_t     temp_c;            /* DHT11: temperatura (C)                    */
    int32_t     humidity;          /* DHT11: umidade (%)                        */
} reading_t;
#endif