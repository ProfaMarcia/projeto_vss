#include <string.h>
#include "app.h"

/* ---- objetos globais ---- */
QueueHandle_t     q_samples;
SemaphoreHandle_t mtx_state;
TaskHandle_t      h_alarm = NULL;
reading_t         g_reading;
volatile int      g_muted = 0;

void setup(){
    Serial.begin(115200);
    delay(200);
    memset(&g_reading, 0, sizeof(g_reading));

    sensor_hal_init();
    actuator_hal_init();
    display_init();   /* LCD inicializado aqui, sem preempcao */

    q_samples = xQueueCreate(SAMPLE_QUEUE_LEN, sizeof(sample_t));
    mtx_state = xSemaphoreCreateMutex();

    /* Atribuicao de prioridades a la Rate-Monotonic, com o alarme (critico) no
     * topo. Tudo fixado no APP_CPU para a analise temporal ficar limpa (1 nucleo).
     * O DHT11 fica na MENOR prioridade: e a carga de interferencia controlada. */
    xTaskCreatePinnedToCore(task_alarm,    "alarm",   2048, NULL, PRIO_ALARM,   &h_alarm, APP_CPU_NUM);
    xTaskCreatePinnedToCore(task_sensor,   "sensor",  2560, NULL, PRIO_SENSOR,  NULL,     APP_CPU_NUM);
    xTaskCreatePinnedToCore(task_detect,   "detect",  3072, NULL, PRIO_DETECT,  NULL,     APP_CPU_NUM);
    xTaskCreatePinnedToCore(task_button,   "button",  2560, NULL, PRIO_BUTTON,  NULL,     APP_CPU_NUM);
    xTaskCreatePinnedToCore(task_comm,     "comm",    4096, NULL, PRIO_COMM,    NULL,     APP_CPU_NUM);
    xTaskCreatePinnedToCore(task_display,  "display", 3072, NULL, PRIO_DISPLAY, NULL,     APP_CPU_NUM);
    xTaskCreatePinnedToCore(task_dht,      "dht",     3072, NULL, PRIO_DHT,     NULL,     APP_CPU_NUM);
    xTaskCreatePinnedToCore(task_watchdog, "wdt",     2560, NULL, PRIO_WDT,     NULL,     APP_CPU_NUM);
}

void loop(){ vTaskDelay(portMAX_DELAY); }
