#include "../app.h"
/* Periódica (T_SENSOR_MS). Lê o ADC e enfileira a amostra com timestamp.
 * Mede o jitter do próprio período. Não bloqueia na fila (mede descartes). */
void task_sensor(void *){
    period_stats_t st; timing_init(&st, (uint64_t)T_SENSOR_MS * 1000ULL, 0);
    TickType_t last = xTaskGetTickCount();
    for (;;){
        int32_t  raw = sensor_hal_read_raw();
        uint64_t now = (uint64_t)esp_timer_get_time();
        uint64_t jit = timing_update(&st, now);

        sample_t s = { raw, now };
        if (xQueueSend(q_samples, &s, 0) != pdTRUE){
            if (xSemaphoreTake(mtx_state, portMAX_DELAY) == pdTRUE){
                g_reading.dropped_samples++; xSemaphoreGive(mtx_state);
            }
        }
        if (xSemaphoreTake(mtx_state, pdMS_TO_TICKS(5)) == pdTRUE){
            g_reading.sensor_jitter_us = jit; xSemaphoreGive(mtx_state);
        }
        vTaskDelayUntil(&last, pdMS_TO_TICKS(T_SENSOR_MS));
    }
}
