#include "../app.h"
/* Dirigida por evento (bloqueia na fila). Converte -> filtra -> decide estado.
 * Atualiza o snapshot e notifica o alarme nas bordas de subida de estado. */
void task_detect(void *){
    moving_avg_t filt;  filter_init(&filt);
    detector_t   det;   detector_init(&det, WARN_PPM, ALARM_PPM, HYST_PPM, DEBOUNCE_N);
    period_stats_t st;  timing_init(&st, (uint64_t)T_SENSOR_MS * 1000ULL, 0);
    gas_state_t  prev = ST_NORMAL;
    sample_t s;
    static uint64_t exec_max = 0;   /* WCET observado da task detect */

    for (;;){
        if (xQueueReceive(q_samples, &s, portMAX_DELAY) == pdTRUE){
            uint64_t now = (uint64_t)esp_timer_get_time();
            uint64_t exec_t0 = now;            /* inicio do trabalho util */
            uint64_t jit = timing_update(&st, now);

            int32_t     ppm  = calib_adc_to_ppm(s.raw);
            int32_t     avg  = filter_push(&filt, ppm);
            gas_state_t st_now = detector_update(&det, avg);
            bool        rose = (st_now > prev);
            if (rose) g_muted = 0;   /* escalada nova reativa o buzzer */

            uint64_t exec = (uint64_t)esp_timer_get_time() - exec_t0;  /* tempo de execucao */
            if (exec > exec_max) exec_max = exec;

            if (xSemaphoreTake(mtx_state, portMAX_DELAY) == pdTRUE){
                g_reading.raw = s.raw; g_reading.ppm = avg; g_reading.state = st_now;
                g_reading.ts_us = now; g_reading.detect_jitter_us = jit;
                g_reading.detect_exec_us = exec;
                g_reading.detect_exec_max_us = exec_max;
                if (rose) g_reading.cross_us = now;   /* marca a borda p/ medir latência */
                xSemaphoreGive(mtx_state);
            }

            /* notifica o alarme em qualquer mudança de estado */
            if (st_now != prev)
                xTaskNotify(h_alarm, (uint32_t)st_now, eSetValueWithOverwrite);

            prev = st_now;
        }
    }
}