#include "../app.h"
/* Maior prioridade (seguranca). Dorme ate ser notificada e atua imediatamente.
 * Mede a latencia fim-a-fim (borda detectada -> atuacao).
 * Respeita o flag g_muted (botao): silencia o buzzer mantendo LED e rele. */
void task_alarm(void *){
    uint32_t notif;
    for (;;){
        if (xTaskNotifyWait(0, 0xFFFFFFFF, &notif, portMAX_DELAY) == pdTRUE){
            uint64_t    now   = (uint64_t)esp_timer_get_time();
            gas_state_t state = (gas_state_t)notif;

            if (state == ST_NORMAL) g_muted = 0;   /* rearma o buzzer */

            actuator_hal_set(state, g_muted);

            if (xSemaphoreTake(mtx_state, portMAX_DELAY) == pdTRUE){
                if (state >= ST_WARNING && g_reading.cross_us > 0 && now >= g_reading.cross_us)
                    g_reading.alarm_latency_us = now - g_reading.cross_us;
                xSemaphoreGive(mtx_state);
            }
        }
    }
}
