#include "../app.h"
/* Evento ESPORADICO. A interrupcao (borda de descida) acorda a task.
 * Mede a latencia ISR -> task acordar (metrica de tempo-real do evento).
 * Acao: silencia o alarme (mute) quando ha WARNING/ALARM ativo. */

static volatile uint64_t s_isr_ts = 0;   /* carimbo de tempo na ISR */
static TaskHandle_t      s_self   = NULL;

static void IRAM_ATTR button_isr(void){
    s_isr_ts = (uint64_t)esp_timer_get_time();
    BaseType_t hpw = pdFALSE;
    vTaskNotifyGiveFromISR(s_self, &hpw);
    if (hpw) portYIELD_FROM_ISR();
}

void task_button(void *){
    s_self = xTaskGetCurrentTaskHandle();
    pinMode(BUTTON_PIN, INPUT_PULLUP);
    attachInterrupt(digitalPinToInterrupt(BUTTON_PIN), button_isr, FALLING);

    for (;;){
        /* bloqueia ate a ISR notificar */
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        uint64_t woke = (uint64_t)esp_timer_get_time();
        uint64_t lat  = (woke >= s_isr_ts) ? (woke - s_isr_ts) : 0;

        /* registra a latencia do evento esporadico */
        if (xSemaphoreTake(mtx_state, portMAX_DELAY) == pdTRUE){
            g_reading.button_latency_us = lat;
            xSemaphoreGive(mtx_state);
        }

        /* debounce: confirma que continua pressionado */
        vTaskDelay(pdMS_TO_TICKS(30));
        if (digitalRead(BUTTON_PIN) == LOW){
            gas_state_t cur;
            if (xSemaphoreTake(mtx_state, portMAX_DELAY) == pdTRUE){
                cur = g_reading.state; xSemaphoreGive(mtx_state);
            }
            if (cur >= ST_WARNING){
                g_muted = 1;
                /* reaplica atuadores imediatamente (silencia o buzzer) */
                if (h_alarm) xTaskNotify(h_alarm, (uint32_t)cur, eSetValueWithOverwrite);
            }
        }
    }
}
