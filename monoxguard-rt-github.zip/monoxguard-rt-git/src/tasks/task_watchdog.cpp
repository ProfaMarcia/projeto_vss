#include "../app.h"
/* Diagnóstico, menor prioridade. Imprime saúde do sistema (uptime/heap).
 * TODO: checar liveness das tasks (carimbos) e marcas d'água de pilha. */
void task_watchdog(void *){
    TickType_t last = xTaskGetTickCount();
    for (;;){
        Serial.printf("[wdt] uptime=%lus heap=%u\n",
                      (unsigned long)(millis() / 1000), (unsigned)ESP.getFreeHeap());
        vTaskDelayUntil(&last, pdMS_TO_TICKS(T_WDT_MS));
    }
}
