#include "../app.h"
/* Periódica, baixa prioridade (soft real-time). Único ponto de impressão:
 * emite CSV limpo p/ os experimentos. MQTT entra aqui como extensão. */
static const char *sname(gas_state_t s){
    return s == ST_ALARM ? "ALARM" : (s == ST_WARNING ? "WARN" : "NORMAL");
}
void task_comm(void *){
    TickType_t last = xTaskGetTickCount();
    Serial.println("t_ms,raw,ppm,state,sensor_jitter_us,detect_jitter_us,alarm_latency_us,button_latency_us,dropped,temp_c,humidity,detect_exec_us,detect_exec_max_us");
    for (;;){
        reading_t r;
        if (xSemaphoreTake(mtx_state, portMAX_DELAY) == pdTRUE){ r = g_reading; xSemaphoreGive(mtx_state); }
        Serial.printf("%lu,%ld,%ld,%s,%llu,%llu,%llu,%llu,%lu,%ld,%ld,%llu,%llu\n",
            (unsigned long)millis(), (long)r.raw, (long)r.ppm, sname(r.state),
            (unsigned long long)r.sensor_jitter_us, (unsigned long long)r.detect_jitter_us,
            (unsigned long long)r.alarm_latency_us, (unsigned long long)r.button_latency_us,
            (unsigned long)r.dropped_samples,
            (long)r.temp_c, (long)r.humidity,
            (unsigned long long)r.detect_exec_us, (unsigned long long)r.detect_exec_max_us);
        /* TODO(MQTT): publicar r aqui se WiFi/MQTT estiver habilitado. */
        vTaskDelayUntil(&last, pdMS_TO_TICKS(T_COMM_MS));
    }
}