#include "../app.h"
#include <math.h>
#include "DHTesp.h"
/* Periodica, MENOR prioridade. Le o DHT11 (temperatura/umidade).
 * A leitura do DHT11 BLOQUEIA ~ dezenas de ms (protocolo bit-bang com timing
 * rigido) -> e a FONTE DE INTERFERENCIA controlada dos experimentos de
 * tempo-real. Para induzir sobrecarga, basta reduzir T_DHT_MS ou subir a
 * prioridade PRIO_DHT. */

static DHTesp dht;

void task_dht(void *){
    dht.setup(DHT_PIN, DHTesp::DHT11);
    TickType_t last = xTaskGetTickCount();
    for (;;){
        TempAndHumidity th = dht.getTempAndHumidity();   /* <- bloqueio proposital */
        if (!isnan(th.temperature) && !isnan(th.humidity)){
            if (xSemaphoreTake(mtx_state, portMAX_DELAY) == pdTRUE){
                g_reading.temp_c   = (int32_t)th.temperature;
                g_reading.humidity = (int32_t)th.humidity;
                xSemaphoreGive(mtx_state);
            }
        }
        vTaskDelayUntil(&last, pdMS_TO_TICKS(T_DHT_MS));
    }
}
