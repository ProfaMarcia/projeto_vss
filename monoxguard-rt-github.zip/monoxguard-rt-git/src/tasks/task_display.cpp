#include "../app.h"
#include <string.h>
#include <stdio.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>
/* Periodica, baixa prioridade. Mostra no LCD 16x2 via I2C (PCF8574).
 * Init feito em display_init() no setup(), antes das tasks. */

static LiquidCrystal_I2C lcd(LCD_I2C_ADDR, LCD_I2C_COLS, LCD_I2C_ROWS);

/* chamada no setup(), sem concorrencia */
void display_init(void){
    Wire.begin();           /* SDA=21, SCL=22 por padrao no ESP32 */
    lcd.init();
    lcd.backlight();
    lcd.clear();
    lcd.setCursor(0, 0); lcd.print("MonoxGuard-RT");
    lcd.setCursor(0, 1); lcd.print("iniciando...");
}

static const char *stag(gas_state_t s){
    return s == ST_ALARM ? "AL" : (s == ST_WARNING ? "WN" : "OK");
}
static const char *categoria(gas_state_t s, int muted){
    switch (s){
        case ST_ALARM:   return muted ? "PERIGO (silenc.)" : "PERIGO! Sair ja";
        case ST_WARNING: return "Atencao: CO alto";
        default:         return "Ambiente Seguro";
    }
}
static const char *recomendacao(gas_state_t s){
    switch (s){
        case ST_ALARM:   return "Abra janelas ja";
        case ST_WARNING: return "Ventile o local";
        default:         return "Tudo OK";
    }
}
static void lcd_line(LiquidCrystal_I2C &d, int row, const char *txt){
    char line[17];
    int n = (int)strlen(txt);
    for (int i = 0; i < 16; i++) line[i] = (i < n) ? txt[i] : ' ';
    line[16] = '\0';
    d.setCursor(0, row);
    d.print(line);
}

void task_display(void *){
    vTaskDelay(pdMS_TO_TICKS(500));
    TickType_t last = xTaskGetTickCount();
    char l0[24], l1[24];
    uint8_t fase = 0, tick = 0;

    for (;;){
        reading_t r;
        if (xSemaphoreTake(mtx_state, portMAX_DELAY) == pdTRUE){ r = g_reading; xSemaphoreGive(mtx_state); }

        snprintf(l0, sizeof l0, "CO:%4ld ppm  %s", (long)r.ppm, stag(r.state));
        lcd_line(lcd, 0, l0);

        switch (fase){
            case 0:  lcd_line(lcd, 1, categoria(r.state, g_muted)); break;
            case 1:  lcd_line(lcd, 1, recomendacao(r.state)); break;
            default: snprintf(l1, sizeof l1, "T:%ldC U:%ld%%", (long)r.temp_c, (long)r.humidity);
                     lcd_line(lcd, 1, l1); break;
        }
        if (++tick >= 7){ tick = 0; fase = (fase + 1) % 3; }
        vTaskDelayUntil(&last, pdMS_TO_TICKS(T_DISPLAY_MS));
    }
}
