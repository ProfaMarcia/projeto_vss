#ifndef APP_H
#define APP_H
#include <Arduino.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "esp_timer.h"

#include "config.h"
#include "shared.h"
#include "hal/sensor_hal.h"
#include "hal/actuator_hal.h"

extern "C" {
#include "core/filter.h"
#include "core/detection.h"
#include "core/calib.h"
#include "metrics/timing.h"
}

/* objetos globais (definidos em main.cpp) */
extern QueueHandle_t     q_samples;
extern SemaphoreHandle_t mtx_state;
extern TaskHandle_t      h_alarm;
extern reading_t         g_reading;
extern volatile int      g_muted;   /* 1 = buzzer silenciado pelo botao */

/* tasks */
void task_sensor(void *);
void task_detect(void *);
void task_alarm(void *);
void task_comm(void *);
void task_watchdog(void *);
void task_display(void *);
void display_init(void);   /* LCD 16x2 (periodica)            */
void task_button(void *);    /* botao (esporadica, ISR)         */
void task_dht(void *);       /* DHT11 (periodica / interferencia)*/
#endif
