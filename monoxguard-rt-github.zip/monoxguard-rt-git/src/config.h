#ifndef CONFIG_H
#define CONFIG_H
/* =========================================================================
 *  MonoxGuard-RT  -  Mapa de pinos (ESP32-WROOM-32 DevKit 30 pinos)
 *  Pinos escolhidos evitando os "strapping pins" (0,2,5,12,15) em saidas
 *  e usando 34 (entrada-only, ADC1) para o sensor analogico.
 * ========================================================================= */

/* ---- Entrada analogica: potenciometro (sim.) OU MQ-7 (via divisor) ---- */
#define SENSOR_PIN        34   /* ADC1_CH6, entrada-only */

/* ---- Atuadores ---- */
#define LED_PIN           4    /* LED + resistor 220R -> GND            */
#define BUZZER_PIN        13   /* buzzer -> GND                         */
#define RELAY_PIN         14   /* modulo rele: pino IN                  */
#define RELAY_ACTIVE_LOW  1    /* rele azul (SONGLE) liga em nivel BAIXO */

/* ---- Botao (evento esporadico, interrupcao) ---- */
#define BUTTON_PIN        27   /* botao -> GND (usa pull-up interno)    */

/* ---- DHT11 (carga/interferencia) ---- */
#define DHT_PIN           26   /* pino DATA do DHT11                    */

/* ---- LCD 16x2 em modo PARALELO (4 bits) ---- */
#define LCD_RS            19
#define LCD_EN            23
#define LCD_D4            18
#define LCD_D5            17
#define LCD_D6            16
#define LCD_D7            25

/* ---- LCD via I2C (PCF8574) ---- */
#define LCD_I2C_ADDR      0x27
#define LCD_I2C_COLS      16
#define LCD_I2C_ROWS      2

/* ---- IPC ---- */
#define SAMPLE_QUEUE_LEN  8

/* ---- Periodos (ms) ---- */
#define T_SENSOR_MS       100   /* amostragem 10 Hz            */
#define T_DISPLAY_MS      300   /* atualizacao do LCD ~3.3 Hz  */
#define T_DHT_MS          2000  /* DHT11 a cada 2 s            */
#define T_COMM_MS         1000  /* telemetria 1 Hz            */
#define T_WDT_MS          2000

/* ---- Deadline do alarme (us): da deteccao do limiar ate atuar ---- */
#define ALARM_DEADLINE_US 50000 /* 50 ms */

/* ---- Prioridades FreeRTOS (maior = mais prioritario) ---- */
#define PRIO_ALARM        6
#define PRIO_SENSOR       5
#define PRIO_DETECT       4
#define PRIO_BUTTON       3
#define PRIO_COMM         2
#define PRIO_DISPLAY      2
#define PRIO_DHT          1
#define PRIO_WDT          1

/* ---- Limiares de deteccao (ppm) ---- */
#define WARN_PPM          300
#define ALARM_PPM         800
#define HYST_PPM          50
#define DEBOUNCE_N        3
#endif
