#ifndef SENSOR_HAL_H
#define SENSOR_HAL_H
#ifdef __cplusplus
extern "C" {
#endif
void sensor_hal_init(void);
int  sensor_hal_read_raw(void);
#ifdef __cplusplus
}
#endif
#endif
