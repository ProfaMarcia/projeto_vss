#include <Arduino.h>
#include "actuator_hal.h"
#include "../config.h"

#define RELAY_ON   (RELAY_ACTIVE_LOW ? LOW  : HIGH)
#define RELAY_OFF  (RELAY_ACTIVE_LOW ? HIGH : LOW)

#define BUZZER_FREQ_HZ 2000   /* tom do alarme (Hz) */

void actuator_hal_init(void){
    pinMode(LED_PIN, OUTPUT);
    pinMode(BUZZER_PIN, OUTPUT);
    pinMode(RELAY_PIN, OUTPUT);
    digitalWrite(LED_PIN, LOW);
    digitalWrite(BUZZER_PIN, LOW);   /* sem noTone() aqui: o canal LEDC ainda nao existe */
    digitalWrite(RELAY_PIN, RELAY_OFF);
}

void actuator_hal_set(gas_state_t s, int muted){
    switch (s){
        case ST_ALARM:
            digitalWrite(LED_PIN, HIGH);
            /* tom oscilante: faz o buzzer (passivo no Wokwi OU ativo no fisico) apitar.
             * digitalWrite(HIGH) so funcionaria em buzzer ativo; tone() cobre os dois. */
            if (muted) noTone(BUZZER_PIN);
            else       tone(BUZZER_PIN, BUZZER_FREQ_HZ);
            digitalWrite(RELAY_PIN, RELAY_ON);    /* liga o "exaustor" */
            break;
        case ST_WARNING:
            digitalWrite(LED_PIN, HIGH);
            noTone(BUZZER_PIN);
            digitalWrite(RELAY_PIN, RELAY_OFF);
            break;
        default:
            digitalWrite(LED_PIN, LOW);
            noTone(BUZZER_PIN);
            digitalWrite(RELAY_PIN, RELAY_OFF);
            break;
    }
}