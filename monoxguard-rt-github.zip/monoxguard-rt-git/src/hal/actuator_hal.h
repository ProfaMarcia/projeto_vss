#ifndef ACTUATOR_HAL_H
#define ACTUATOR_HAL_H
#include "../core/detection.h"   /* gas_state_t (tem guarda extern C) */
#ifdef __cplusplus
extern "C" {
#endif
void actuator_hal_init(void);
/* aplica estado nos atuadores; muted=1 silencia o buzzer (LED e rele seguem) */
void actuator_hal_set(gas_state_t state, int muted);
#ifdef __cplusplus
}
#endif
#endif
