#include <Arduino.h>
#include "sensor_hal.h"
#include "../config.h"
void sensor_hal_init(void){ analogReadResolution(12); pinMode(SENSOR_PIN, INPUT); }
int  sensor_hal_read_raw(void){ return analogRead(SENSOR_PIN); }
