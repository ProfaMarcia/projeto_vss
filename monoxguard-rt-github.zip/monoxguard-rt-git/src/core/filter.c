#include "filter.h"

void filter_init(moving_avg_t *f) {
    size_t i;
    f->count = 0;
    f->head  = 0;
    f->sum   = 0;
    for (i = 0; i < FILTER_WINDOW; i++) f->buffer[i] = 0;
}

/* Média móvel sobre janela circular. Propriedades verificáveis:
 *  - head sempre em [0, FILTER_WINDOW-1]
 *  - count nunca excede FILTER_WINDOW
 *  - divisão segura (count >= 1 ao retornar) */
int32_t filter_push(moving_avg_t *f, int32_t sample) {
    if (f->count == FILTER_WINDOW) {
        f->sum -= f->buffer[f->head];   /* remove a mais antiga (posição head) */
    } else {
        f->count++;
    }
    f->buffer[f->head] = sample;
    f->sum += sample;
    f->head = (f->head + 1) % FILTER_WINDOW;
    return (int32_t)(f->sum / (int64_t)f->count);
}
