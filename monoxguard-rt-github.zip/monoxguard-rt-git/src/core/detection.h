#ifndef DETECTION_H
#define DETECTION_H
#ifdef __cplusplus
extern "C" {
#endif
#include <stdint.h>

typedef enum { ST_NORMAL = 0, ST_WARNING = 1, ST_ALARM = 2 } gas_state_t;

typedef struct {
    int32_t     threshold_warn;
    int32_t     threshold_alarm;
    int32_t     hysteresis;   /* margem para voltar a descer (evita chattering) */
    uint8_t     debounce_n;   /* amostras consecutivas p/ confirmar transição */
    gas_state_t state;
    uint8_t     counter;
} detector_t;

void        detector_init(detector_t *d, int32_t warn, int32_t alarm,
                          int32_t hyst, uint8_t debounce);
gas_state_t detector_update(detector_t *d, int32_t ppm);

#ifdef __cplusplus
}
#endif
#endif
