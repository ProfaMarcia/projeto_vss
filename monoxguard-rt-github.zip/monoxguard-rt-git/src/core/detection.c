#include "detection.h"

void detector_init(detector_t *d, int32_t warn, int32_t alarm,
                   int32_t hyst, uint8_t debounce) {
    d->threshold_warn  = warn;
    d->threshold_alarm = alarm;
    d->hysteresis      = hyst;
    d->debounce_n      = (debounce == 0) ? 1 : debounce;
    d->state           = ST_NORMAL;
    d->counter         = 0;
}

/* Máquina de estados com histerese + debounce. Propriedades verificáveis:
 *  - estado sempre em {NORMAL, WARNING, ALARM}
 *  - só vai para ALARM com ppm >= alarme sustentado por debounce_n amostras */
gas_state_t detector_update(detector_t *d, int32_t ppm) {
    gas_state_t target;

    if (ppm >= d->threshold_alarm)                     target = ST_ALARM;
    else if (ppm >= d->threshold_warn)                 target = ST_WARNING;
    else if (ppm <  d->threshold_warn - d->hysteresis) target = ST_NORMAL;
    else                                               target = d->state; /* banda de histerese: segura */

    if (target == d->state) {
        d->counter = 0;
    } else {
        if (d->counter < 255) d->counter++;
        if (d->counter >= d->debounce_n) {
            d->state   = target;
            d->counter = 0;
        }
    }
    return d->state;
}
