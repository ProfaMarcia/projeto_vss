#ifndef FILTER_H
#define FILTER_H
#ifdef __cplusplus
extern "C" {
#endif
#include <stdint.h>
#include <stddef.h>

/* Janela pequena de propósito: facilita a verificação (unwinding) no CBMC/ESBMC. */
#define FILTER_WINDOW 8

typedef struct {
    int32_t buffer[FILTER_WINDOW];
    size_t  count;   /* amostras válidas, 0..FILTER_WINDOW */
    size_t  head;    /* próximo índice de escrita, 0..FILTER_WINDOW-1 */
    int64_t sum;     /* soma corrente das amostras válidas */
} moving_avg_t;

void    filter_init(moving_avg_t *f);
int32_t filter_push(moving_avg_t *f, int32_t sample);

#ifdef __cplusplus
}
#endif
#endif
