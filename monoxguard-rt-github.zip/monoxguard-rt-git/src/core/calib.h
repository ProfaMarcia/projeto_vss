#ifndef CALIB_H
#define CALIB_H
#ifdef __cplusplus
extern "C" {
#endif
#include <stdint.h>

#define ADC_MAX 4095
#define PPM_MAX 10000

/* Converte leitura bruta do ADC [0,ADC_MAX] em ppm [0,PPM_MAX], com clamp.
 * TODO(calibração): trocar o mapa linear pela curva real do MQ-5 (Rs/R0). */
int32_t calib_adc_to_ppm(int32_t raw);

#ifdef __cplusplus
}
#endif
#endif
