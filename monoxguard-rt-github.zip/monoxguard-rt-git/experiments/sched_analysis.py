#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Simulador de escalonabilidade do MonoxGuard-RT (PGENE537).
Modelo de tarefas periodicas, prioridade fixa (Rate-Monotonic-like).
Calcula: utilizacao, teste de Liu & Layland, analise de tempo de resposta (RTA)
e gera grafico de Gantt da simulacao.
"""
import math
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches

# ----------------------------------------------------------------------
# Modelo de tarefas. Tempos em microssegundos (us).
# C = WCET; T = periodo; prio (maior numero = maior prioridade, padrao FreeRTOS).
# WCET: 'detect' medido (38 us). Demais: estimados pela natureza da tarefa
# (declarado como estimativa no relatorio). So tarefas PERIODICAS entram na
# analise de utilizacao; alarme e botao sao esporadicas/reativas.
# ----------------------------------------------------------------------
TASKS = [
    # nome,        C(us),  T(us),    prio, periodica?
    ("sensor",       40,   100_000,   5, True),
    ("detect",       38,   100_000,   4, True),   # WCET medido
    ("comm",        120,  1000_000,   2, True),
    ("display",     900,   300_000,   2, True),   # escrita no LCD e mais lenta
    ("dht",         800,  2000_000,   1, True),
    ("watchdog",     20,  2000_000,   1, True),
]

def utilizacao(tasks):
    return sum(C/T for (_,C,T,_,per) in tasks if per)

def limite_LL(n):
    return n*(2**(1/n)-1)

def rta(tasks):
    """Analise de tempo de resposta (prioridade fixa, preemptivo).
    Para cada tarefa i: R = C_i + soma_{j de maior prio} ceil(R/T_j)*C_j."""
    periodic = [(nome,C,T,prio) for (nome,C,T,prio,per) in tasks if per]
    res = {}
    for (nome,C,T,prio) in periodic:
        hp = [(c,t) for (n2,c,t,p2) in periodic if p2 > prio]  # maior prioridade
        R = C
        for _ in range(1000):
            interf = sum(math.ceil(R/t)*c for (c,t) in hp)
            novo = C + interf
            if novo == R:
                break
            R = novo
            if R > T*10:   # divergiu
                R = None; break
        res[nome] = (R, T)
    return res

def gantt(tasks, horizon=600_000, fname="gantt.png"):
    """Simulacao simples de escalonamento preemptivo por prioridade fixa."""
    periodic = sorted([(n,C,T,p) for (n,C,T,p,per) in tasks if per],
                      key=lambda x:-x[3])  # maior prioridade primeiro
    dt = 100  # passo 100 us
    # estado: proxima liberacao e tempo restante de cada job
    rem = {n:0 for (n,_,_,_) in periodic}
    nextrel = {n:0 for (n,_,_,_) in periodic}
    segments = {n:[] for (n,_,_,_) in periodic}
    t = 0
    cur = None; seg_start=None
    while t < horizon:
        # libera jobs
        for (n,C,T,p) in periodic:
            if t >= nextrel[n]:
                rem[n] += C
                nextrel[n] += T
        # escolhe tarefa de maior prioridade com trabalho pendente
        run = None
        for (n,C,T,p) in periodic:
            if rem[n] > 0:
                run = n; break
        if run != cur:
            if cur is not None and seg_start is not None:
                segments[cur].append((seg_start, t))
            cur = run; seg_start = t if run else None
        if run:
            rem[run] -= dt
            if rem[run] < 0: rem[run] = 0
        t += dt
    if cur is not None and seg_start is not None:
        segments[cur].append((seg_start, t))

    fig, ax = plt.subplots(figsize=(11,4))
    cores = {"sensor":"#2a9d8f","detect":"#e76f51","comm":"#264653",
             "display":"#e9c46a","dht":"#8ab17d","watchdog":"#9b5de5"}
    ynames = [n for (n,_,_,_) in periodic]
    for i,(n,C,T,p) in enumerate(periodic):
        for (s,e) in segments[n]:
            ax.barh(i, (e-s)/1000.0, left=s/1000.0, height=0.6,
                    color=cores.get(n,"#888"), edgecolor="black", linewidth=0.3)
    ax.set_yticks(range(len(periodic)))
    ax.set_yticklabels([f"{n} (P{p})" for (n,_,_,p) in periodic])
    ax.set_xlabel("tempo (ms)")
    ax.set_title("MonoxGuard-RT — Gantt do escalonamento (prioridade fixa, 1 núcleo)")
    ax.grid(axis="x", alpha=0.3)
    plt.tight_layout(); plt.savefig(fname, dpi=130); plt.close()
    return fname

# ---------------- relatorio ----------------
U = utilizacao(TASKS)
n = len([1 for t in TASKS if t[4]])
LL = limite_LL(n)
print("="*60)
print("ANALISE DE ESCALONABILIDADE — MonoxGuard-RT")
print("="*60)
print(f"\nTarefas periodicas: {n}")
print(f"{'tarefa':<10}{'C(us)':>8}{'T(ms)':>9}{'Ci/Ti':>10}{'prio':>6}")
for (nome,C,T,prio,per) in TASKS:
    if per:
        print(f"{nome:<10}{C:>8}{T/1000:>9.0f}{C/T:>10.5f}{prio:>6}")
print(f"\nUtilizacao total U = {U:.5f}  ({U*100:.3f}% da CPU)")
print(f"Limite de Liu & Layland p/ n={n}: {LL:.4f}  ({LL*100:.2f}%)")
print(f"Escalonavel por RM (U <= limite)? {'SIM' if U<=LL else 'verificar via RTA'}")
print(f"Utilizacao tambem < 1.0 (condicao necessaria)? {'SIM' if U<1 else 'NAO'}")

print("\nAnalise de Tempo de Resposta (RTA):")
print(f"{'tarefa':<10}{'R(us)':>10}{'deadline=T(ms)':>16}{'OK?':>6}")
for nome,(R,T) in rta(TASKS).items():
    ok = "SIM" if (R is not None and R<=T) else "NAO"
    Rs = f"{R}" if R is not None else "div"
    print(f"{nome:<10}{Rs:>10}{T/1000:>16.0f}{ok:>6}")

gantt(TASKS, fname="gantt_monoxguard.png")
print("\nGrafico de Gantt salvo: gantt_monoxguard.png")
