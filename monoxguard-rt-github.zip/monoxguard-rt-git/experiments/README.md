# Experimentos

Capture a saída CSV da serial (task comm) para `data/run_XX.csv` e gere os gráficos.

## Roteiro sugerido
1. **Nominal:** rode ~5 min, meça jitter (sensor/detect) e latência do alarme.
2. **Resposta do alarme:** varra o potenciômetro acima do limiar N vezes; histograma de `alarm_latency_us`.
3. **Sobrecarga:** reduza T_SENSOR_MS (ex.: 100→20 ms) e/ou adicione task de carga;
   meça jitter, descartes (`dropped`) e deadline misses vs carga.
4. **Inversão de prioridade:** segure `mtx_state` na comm por X ms; compare a latência
   do alarme com mutex (herança) vs uma flag sem proteção. Gere o gráfico antes/depois.
