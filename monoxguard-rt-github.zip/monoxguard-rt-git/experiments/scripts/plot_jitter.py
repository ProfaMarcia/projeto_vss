#!/usr/bin/env python3
"""Lê um CSV capturado da serial e plota jitter e latência do alarme."""
import sys, csv
import matplotlib.pyplot as plt

def load(path):
    rows = list(csv.DictReader(open(path)))
    return rows

def main(path):
    rows = load(path)
    sj = [int(r["sensor_jitter_us"]) for r in rows if r["sensor_jitter_us"].isdigit()]
    lat = [int(r["alarm_latency_us"]) for r in rows if int(r["alarm_latency_us"]) > 0]
    fig, ax = plt.subplots(1, 2, figsize=(10, 4))
    ax[0].hist(sj, bins=30); ax[0].set_title("Jitter do sensor (us)"); ax[0].set_xlabel("us")
    if lat:
        ax[1].hist(lat, bins=30); ax[1].set_title("Latência do alarme (us)"); ax[1].set_xlabel("us")
    plt.tight_layout(); plt.savefig("jitter_latency.png", dpi=120)
    print("salvo: jitter_latency.png")

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "../data/run_01.csv")
