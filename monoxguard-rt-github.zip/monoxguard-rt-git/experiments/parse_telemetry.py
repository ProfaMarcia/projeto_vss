#!/usr/bin/env python3
"""
parse_telemetry.py  --  Analise da telemetria de tempo real do MonoxGuard-RT

Le um dump BRUTO do Serial Monitor (mesmo com as linhas [wdt] cortando o CSV no
meio, espacos no inicio, lixo de boot) e produz:

  - telemetry_clean.csv      -> so as linhas validas, ordenadas por tempo
  - summary.md / summary.csv -> tabela de metricas (por estado, latencia, jitter, heap)
  - plot_timeline.png        -> ppm x tempo com faixas de estado (NORMAL/WARN/ALARM)
  - plot_latency.png         -> latencia do alarme por evento (limiar -> atuacao)
  - plot_jitter.png          -> jitter de sensor/detect (se houver)

Formato esperado do CSV (definido em task_comm.cpp):
  t_ms,raw,ppm,state,sensor_jitter_us,detect_jitter_us,alarm_latency_us,dropped

IMPORTANTE: numeros temporais aqui sao MEDIDOS EM SIMULACAO (Wokwi). Rotule assim
no relatorio; o Wokwi nao e cycle-accurate (ver secao de limitacoes).

Uso:
  python parse_telemetry.py serial_raw.log
  python parse_telemetry.py serial_raw.log --out ./resultados --scenario "subida_gradual_run1"
"""

import argparse, os, re, sys
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

# Casa uma linha de telemetria em QUALQUER lugar do texto (mesmo com lixo em volta).
# Aceita os dois formatos: com (9 col) ou sem (8 col) a coluna button_latency_us.
ROW_RE = re.compile(
    r"(?P<t>\d+),(?P<raw>-?\d+),(?P<ppm>-?\d+),"
    r"(?P<state>NORMAL|WARN|WARNING|ALARM),"
    r"(?P<sjit>\d+),(?P<djit>\d+),(?P<alat>\d+),"
    r"(?:(?P<blat>\d+),)?"            # button_latency_us (opcional, formato novo)
    r"(?P<drop>\d+)"
    r"(?:,(?P<temp>-?\d+),(?P<hum>-?\d+),(?P<dexec>\d+),(?P<dexecmax>\d+))?"  # DHT + WCET (opcional)
)
WDT_RE = re.compile(r"\[wdt\]\s+uptime=(?P<up>\d+)s\s+heap=(?P<heap>\d+)")


def load_raw(path):
    with open(path, "r", errors="replace") as f:
        text = f.read()

    rows = [m.groupdict() for m in ROW_RE.finditer(text)]
    if not rows:
        sys.exit("Nenhuma linha de telemetria reconhecida. Confira o formato do CSV.")
    df = pd.DataFrame(rows)
    if "blat" not in df.columns:
        df["blat"] = None
    df["blat"] = df["blat"].fillna(0)
    for opt in ["temp", "hum", "dexec", "dexecmax"]:
        if opt not in df.columns:
            df[opt] = None
        df[opt] = df[opt].fillna(0)
    for c in ["t", "raw", "ppm", "sjit", "djit", "alat", "blat", "drop",
              "temp", "hum", "dexec", "dexecmax"]:
        df[c] = pd.to_numeric(df[c])
    df["state"] = df["state"].replace({"WARNING": "WARN"})
    df = df.drop_duplicates(subset="t").sort_values("t").reset_index(drop=True)
    df["t_s"] = (df["t"] - df["t"].iloc[0]) / 1000.0

    wdt = pd.DataFrame([m.groupdict() for m in WDT_RE.finditer(text)])
    if not wdt.empty:
        wdt["up"] = pd.to_numeric(wdt["up"]); wdt["heap"] = pd.to_numeric(wdt["heap"])
    return df, wdt


def detect_transitions(df):
    """Lista as bordas de estado (de->para) com timestamp."""
    trans = []
    prev = None
    for _, r in df.iterrows():
        if prev is not None and r["state"] != prev:
            trans.append({"t_ms": int(r["t"]), "t_s": round(r["t_s"], 1),
                          "de": prev, "para": r["state"],
                          "ppm": int(r["ppm"]), "raw": int(r["raw"])})
        prev = r["state"]
    return pd.DataFrame(trans)


def summarize(df, wdt, trans):
    lines = []
    dur = df["t_s"].iloc[-1] - df["t_s"].iloc[0]
    lines.append(f"# Resumo da telemetria — MonoxGuard-RT (simulação Wokwi)\n")
    lines.append(f"- Amostras válidas: **{len(df)}**")
    lines.append(f"- Duração coberta: **{dur:.0f} s** ({df['t'].iloc[0]} → {df['t'].iloc[-1]} ms)")
    lines.append(f"- Amostras descartadas (dropped, máx): **{int(df['drop'].max())}**\n")

    # Tempo em cada estado (cada amostra ~ T_COMM = 1 s)
    lines.append("## Tempo por estado")
    counts = df["state"].value_counts()
    for st in ["NORMAL", "WARN", "ALARM"]:
        n = int(counts.get(st, 0))
        lines.append(f"- {st}: {n} amostras (~{n} s, {100*n/len(df):.1f}%)")
    lines.append("")

    # Transições
    lines.append("## Transições de estado")
    if trans.empty:
        lines.append("- Nenhuma transição capturada (estado constante).")
    else:
        for _, r in trans.iterrows():
            lines.append(f"- t={r['t_s']:.0f}s: **{r['de']} → {r['para']}** (ppm={r['ppm']}, raw={r['raw']})")
    lines.append("")

    # Latência do alarme
    lat = df.loc[df["alat"] > 0, "alat"]
    lines.append("## Latência do alarme (limiar → atuação)")
    if lat.empty:
        lines.append("- Nenhuma latência > 0 registrada.")
    else:
        lines.append(f"- valor observado: min={lat.min()} µs, média={lat.mean():.1f} µs, "
                     f"máx={lat.max()} µs (deadline configurado: 50000 µs)")
        n_alarm_trans = 0 if trans.empty else int(((trans["para"] == "ALARM")).sum())
        lines.append(f"- nº de transições NORMAL/WARN → ALARM distintas: **{n_alarm_trans}** "
                     f"(o campo alat fica *latched* no último valor; para média estatística "
                     f"é preciso múltiplas transições, uma por execução de cenário)")
    lines.append("")

    # Latência do botão (ISR -> task)
    blat = df.loc[df["blat"] > 0, "blat"]
    lines.append("## Latência do botão (ISR → task) — evento esporádico")
    if blat.empty:
        lines.append("- Nenhuma latência > 0 registrada (botão MUTE não acionado neste log).")
    else:
        lines.append(f"- valor observado: min={blat.min()} µs, média={blat.mean():.1f} µs, "
                     f"máx={blat.max()} µs (campo *latched*; para média estatística, "
                     f"acione o MUTE várias vezes)")
    lines.append("")

    # WCET observado (task detect)
    dex = df.loc[df["dexecmax"] > 0, "dexecmax"]
    lines.append("## WCET observado — task detect (calib + filtro + decisão)")
    if dex.empty:
        lines.append("- Não reportado neste log (formato antigo sem coluna de WCET).")
    else:
        cur = df.loc[df["dexec"] > 0, "dexec"]
        lines.append(f"- **WCET observado (máx): {int(dex.max())} µs**")
        if not cur.empty:
            lines.append(f"- execução por ativação: média={cur.mean():.1f} µs, máx={int(cur.max())} µs")
        lines.append("- *Estimativa empírica por medição (não WCET analítico). Em simulação Wokwi "
                     "o tempo é idealizado; em hardware seria maior.*")
    lines.append("")

    # Dados do sensor DHT
    temp = df.loc[df["temp"] != 0, "temp"]
    hum = df.loc[df["hum"] != 0, "hum"]
    lines.append("## Dados do sensor DHT")
    if temp.empty and hum.empty:
        lines.append("- Sem leituras de temperatura/umidade neste log.")
    else:
        if not temp.empty:
            lines.append(f"- temperatura: média={temp.mean():.1f} °C (min={int(temp.min())}, máx={int(temp.max())})")
        if not hum.empty:
            lines.append(f"- umidade: média={hum.mean():.1f} % (min={int(hum.min())}, máx={int(hum.max())})")
    lines.append("")

    # Jitter
    lines.append("## Jitter de período (µs)")
    for col, nome in [("sjit", "sensor"), ("djit", "detect")]:
        s = df[col]
        lines.append(f"- {nome}: min={s.min()}, média={s.mean():.1f}, máx={s.max()}")
    lines.append("- (jitter ~0 é característico da simulação Wokwi — timing idealizado, "
                 "não cycle-accurate; em hardware físico haveria jitter mensurável.)\n")

    # Heap
    if not wdt.empty:
        lines.append("## Estabilidade de memória (watchdog)")
        lines.append(f"- heap: min={int(wdt['heap'].min())} B, máx={int(wdt['heap'].max())} B "
                     f"(variação={int(wdt['heap'].max()-wdt['heap'].min())} B → "
                     f"{'estável, sem vazamento aparente' if wdt['heap'].max()-wdt['heap'].min()==0 else 'verificar'})")
        lines.append(f"- uptime final: {int(wdt['up'].max())} s\n")

    return "\n".join(lines)


def make_plots(df, wdt, outdir, scenario):
    band = {"NORMAL": "#1FC9A1", "WARN": "#F4B400", "ALARM": "#DB4437"}

    # Timeline ppm + faixas de estado
    fig, ax = plt.subplots(figsize=(11, 4.2))
    ax.plot(df["t_s"], df["ppm"], color="#005087", lw=1.6, label="ppm (filtrado)")
    ax.axhline(300, color="#F4B400", ls="--", lw=1, label="limiar WARN (300)")
    ax.axhline(800, color="#DB4437", ls="--", lw=1, label="limiar ALARM (800)")
    # sombreia trechos por estado
    cur = df["state"].iloc[0]; start = df["t_s"].iloc[0]
    for i in range(1, len(df)):
        if df["state"].iloc[i] != cur:
            ax.axvspan(start, df["t_s"].iloc[i], color=band.get(cur, "#ccc"), alpha=0.12)
            cur = df["state"].iloc[i]; start = df["t_s"].iloc[i]
    ax.axvspan(start, df["t_s"].iloc[-1], color=band.get(cur, "#ccc"), alpha=0.12)
    ax.set_xlabel("tempo (s)"); ax.set_ylabel("ppm")
    ax.set_title(f"MonoxGuard-RT — ppm e estado ao longo do tempo (Wokwi){' · '+scenario if scenario else ''}")
    ax.legend(loc="upper right", fontsize=8); ax.grid(alpha=0.25)
    fig.tight_layout(); fig.savefig(os.path.join(outdir, "plot_timeline.png"), dpi=140); plt.close(fig)

    # Latência do alarme por evento
    lat = df.loc[df["alat"] > 0]
    if not lat.empty:
        fig, ax = plt.subplots(figsize=(7, 3.6))
        ax.plot(lat["t_s"], lat["alat"], "o-", color="#DB4437", ms=4)
        ax.set_xlabel("tempo (s)"); ax.set_ylabel("latência do alarme (µs)")
        ax.set_title("Latência limiar → atuação (deadline = 50000 µs)")
        ax.grid(alpha=0.25); fig.tight_layout()
        fig.savefig(os.path.join(outdir, "plot_latency.png"), dpi=140); plt.close(fig)

    # Jitter
    fig, ax = plt.subplots(figsize=(7, 3.6))
    ax.plot(df["t_s"], df["sjit"], label="sensor", color="#005087")
    ax.plot(df["t_s"], df["djit"], label="detect", color="#1FC9A1")
    ax.set_xlabel("tempo (s)"); ax.set_ylabel("jitter (µs)")
    ax.set_title("Jitter de período por task (Wokwi)")
    ax.legend(fontsize=8); ax.grid(alpha=0.25); fig.tight_layout()
    fig.savefig(os.path.join(outdir, "plot_jitter.png"), dpi=140); plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("log", help="arquivo de log bruto do Serial Monitor")
    ap.add_argument("--out", default=".", help="diretório de saída")
    ap.add_argument("--scenario", default="", help="rótulo do cenário (ex.: subida_gradual_run1)")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    df, wdt = load_raw(args.log)
    trans = detect_transitions(df)

    df.to_csv(os.path.join(args.out, "telemetry_clean.csv"), index=False)
    summary = summarize(df, wdt, trans)
    open(os.path.join(args.out, "summary.md"), "w").write(summary)

    # tabela compacta em CSV (por estado)
    tab = df.groupby("state").agg(
        amostras=("t", "count"), ppm_med=("ppm", "mean"),
        ppm_max=("ppm", "max"), raw_med=("raw", "mean")).round(1)
    tab.to_csv(os.path.join(args.out, "summary.csv"))

    make_plots(df, wdt, args.out, args.scenario)
    print(summary)
    print(f"\n[ok] arquivos gerados em: {os.path.abspath(args.out)}")


if __name__ == "__main__":
    main()
