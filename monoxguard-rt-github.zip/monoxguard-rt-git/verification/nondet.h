#ifndef NONDET_H
#define NONDET_H
#include <stdint.h>
/* CBMC/ESBMC tratam funções cujo nome começa com "nondet_" como valores não-determinísticos. */
int32_t  nondet_int32(void);
uint32_t nondet_uint32(void);

/* assume() portátil entre CBMC e ESBMC */
#if defined(__CPROVER)
#  define ASSUME(c) __CPROVER_assume(c)
#else
void __VERIFIER_assume(int);
#  define ASSUME(c) __VERIFIER_assume(c)
#endif
#endif
