#include <assert.h>
#include "nondet.h"
#include "../src/core/calib.h"

/* Versão ingênua (BUGADA) p/ o experimento "achar o bug": 32 bits + sem clamp.
 * raw grande -> overflow de inteiro com sinal (UB). */
static int32_t calib_naive(int32_t raw){ return (raw * PPM_MAX) / ADC_MAX; }

int main(void){
    int32_t raw = nondet_int32();

    /* A versão SEGURA deve permanecer limitada para QUALQUER entrada: PASSA. */
    int32_t ppm = calib_adc_to_ppm(raw);
    assert(ppm >= 0 && ppm <= PPM_MAX);

    /* Descomente para ver o ESBMC/CBMC gerar o contraexemplo de overflow: FALHA.
    int32_t bad = calib_naive(raw);
    assert(bad >= 0 && bad <= PPM_MAX);
    */
    (void)calib_naive;
    return 0;
}
