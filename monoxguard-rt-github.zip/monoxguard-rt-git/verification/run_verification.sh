#!/bin/sh
# Verificação do núcleo de lógica pura com CBMC e/ou ESBMC.
# Requer cbmc e/ou esbmc no PATH.
CORE=../src/core
CBMC_FLAGS="--bounds-check --pointer-check --signed-overflow-check --unsigned-overflow-check --div-by-zero-check --unwind 60"
ESBMC_FLAGS="--bounds-check --pointer-check --overflow-check --div-by-zero-check --unwind 60"

for h in harness_filter harness_detection harness_calib; do
    echo "================= $h ================="
    if command -v cbmc >/dev/null 2>&1; then
        echo "--- CBMC ---";  cbmc  "$h.c" "$CORE"/*.c -I . -I "$CORE" $CBMC_FLAGS
    fi
    if command -v esbmc >/dev/null 2>&1; then
        echo "--- ESBMC ---"; esbmc "$h.c" "$CORE"/*.c -I . -I "$CORE" $ESBMC_FLAGS
    fi
done
