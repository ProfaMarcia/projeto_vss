#include <assert.h>
#include "nondet.h"
#include "../src/core/filter.h"

/* Prova: invariantes da janela circular para QUALQUER sequência de entradas. */
int main(void){
    moving_avg_t f; filter_init(&f);
    uint32_t n = nondet_uint32();
    ASSUME(n <= 3 * FILTER_WINDOW);            /* limita o unwinding */
    for (uint32_t i = 0; i < n; i++){
        int32_t x = nondet_int32();
        ASSUME(x >= 0 && x <= 10000);
        int32_t avg = filter_push(&f, x);
        assert(f.head < FILTER_WINDOW);        /* índice nunca estoura */
        assert(f.count <= FILTER_WINDOW);
        assert(f.count >= 1);                  /* divisão segura */
        assert(avg >= 0 && avg <= 10000);      /* média de entradas limitadas */
    }
    return 0;
}
