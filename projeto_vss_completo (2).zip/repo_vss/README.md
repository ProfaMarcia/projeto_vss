# MonoxGuard-RT — Verificação Formal da Lógica Crítica

Verificação formal por *Bounded Model Checking* (BMC) da lógica crítica do **MonoxGuard-RT**, um detector de monóxido de carbono (CO) embarcado em ESP32/FreeRTOS.

> O MonoxGuard-RT foi desenvolvido como um sistema de tempo-real (ESP32/FreeRTOS). **Este repositório foca na verificação formal de sua lógica crítica** — a camada de lógica pura do firmware, independente de hardware.

## Objetivo

Provar, e não apenas testar, propriedades de segurança da lógica de decisão do detector, usando duas ferramentas de *model checking* com fundamentos distintos:

- **ESBMC** 8.2.0 — BMC sobre **SMT** (*solver* Z3 4.8.12)
- **CBMC** 5.95.1 — BMC sobre **SAT** (*solver* MiniSAT 2.2.1)

## Propriedades verificadas

| Módulo | Propriedade | Resultado |
|--------|-------------|-----------|
| `calib` | A conversão ADC→ppm nunca sai de `[0, PPM_MAX]` | ✅ SUCCESSFUL |
| `detection` | Estado sempre válido + vivacidade (3×≥800 ppm ⇒ ALARM) | ✅ SUCCESSFUL |
| `filter` | Invariantes da janela circular (índice, divisão segura, média) | ✅ SUCCESSFUL |
| `calib_bug` | Versão ingênua em 32 bits (experimento de injeção de falha) | ❌ FAILED (overflow) |

As três propriedades foram provadas por **ambas** as ferramentas. O experimento de injeção de falha produziu um contraexemplo de *overflow* aritmético, confirmando a capacidade de detecção de defeitos.

## Estrutura do repositório

```
.
├── src/core/                 Lógica pura verificada (independente de hardware)
│   ├── calib.c / calib.h         conversão ADC→ppm com clamp (int64)
│   ├── detection.c / detection.h máquina de estados de alarme
│   └── filter.c / filter.h       filtro de média móvel (janela circular N=8)
├── verification/             Harnesses e scripts
│   ├── harness_calib.c           propriedade de limites da calibração
│   ├── harness_calib_bug.c       experimento de injeção de falha (overflow)
│   ├── harness_detection.c       validade de estado + vivacidade
│   ├── harness_filter.c          invariantes da janela circular
│   ├── nondet.h                  entradas não-determinísticas + ASSUME
│   └── run_verification.sh       roda tudo e salva os resultados
├── resultados_verificacao/   Logs completos de cada verificação + RESUMO
└── docs/                     Artigo (PDF + LaTeX)
```

## Como reproduzir

Pré-requisitos: **ESBMC** e **CBMC** instalados.

```bash
cd verification
bash run_verification.sh
```

Os resultados são salvos em `resultados_verificacao/`, com um `RESUMO.txt` ao final.

### Comandos individuais (exemplos)

```bash
# Propriedade da calibração (ESBMC)
esbmc harness_calib.c ../src/core/calib.c -I . -I ../src/core --overflow-check

# Mesma propriedade (CBMC)
cbmc harness_calib.c ../src/core/calib.c -I . -I ../src/core \
     --signed-overflow-check --bounds-check --div-by-zero-check

# Experimento de injeção de falha (espera FAILED com contraexemplo de overflow)
esbmc harness_calib_bug.c ../src/core/calib.c -I . -I ../src/core --overflow-check
```

> Observação: o ESBMC habilita verificações de limites e divisão por zero por padrão; no CBMC elas são ativadas explicitamente. O módulo `filter` envolve divisão de 64 bits e é o caso computacionalmente mais custoso — a codificação SAT do CBMC gera um número elevado de cláusulas conforme o limite de desenrolamento aumenta.

## Autores

Bruno Gonçalves · Dioneide Sales · Márcia Silva
PPGEE / UFAM
