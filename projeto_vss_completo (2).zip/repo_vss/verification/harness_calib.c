#include <assert.h>
#include "nondet.h"
#include "../src/core/calib.h"

int main(void){
    int32_t raw = nondet_int32();
    int32_t ppm = calib_adc_to_ppm(raw);
    assert(ppm >= 0 && ppm <= PPM_MAX);
    return 0;
}
