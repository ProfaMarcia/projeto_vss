#ifndef NONDET_H
#define NONDET_H
#include <stdint.h>
int32_t  nondet_int32(void);
uint32_t nondet_uint32(void);
#if defined(__CPROVER)
#  define ASSUME(c) __CPROVER_assume(c)
#else
void __VERIFIER_assume(int);
#  define ASSUME(c) __VERIFIER_assume(c)
#endif
#endif
