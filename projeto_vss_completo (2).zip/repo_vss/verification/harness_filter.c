#include <assert.h>
#include "nondet.h"
#include "../src/core/filter.h"

int main(void){
    moving_avg_t f; filter_init(&f);
    uint32_t n = nondet_uint32();
    ASSUME(n <= 3 * FILTER_WINDOW);
    for (uint32_t i = 0; i < n; i++){
        int32_t x = nondet_int32();
        ASSUME(x >= 0 && x <= 10000);
        int32_t avg = filter_push(&f, x);
        assert(f.head < FILTER_WINDOW);
        assert(f.count <= FILTER_WINDOW);
        assert(f.count >= 1);
        assert(avg >= 0 && avg <= 10000);
    }
    return 0;
}
