#include <assert.h>
#include "nondet.h"
#include "../src/core/calib.h"

/* EXPERIMENTO DE INJECAO DE FALHA: versao ingenua (32 bits, sem clamp).
 * raw * PPM_MAX estoura int32 -> overflow. Esperado: VERIFICATION FAILED. */
static int32_t calib_naive(int32_t raw){ return (raw * PPM_MAX) / ADC_MAX; }

int main(void){
    int32_t raw = nondet_int32();
    ASSUME(raw >= 0);
    int32_t bad = calib_naive(raw);
    assert(bad >= 0 && bad <= PPM_MAX);
    return 0;
}
