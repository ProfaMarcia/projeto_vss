#!/bin/bash
# Roda todas as verificacoes e salva em resultados_verificacao/
# Uso: bash run_verification.sh
C=../src/core
O=../resultados_verificacao
mkdir -p "$O"
echo "Rodando verificacoes (filter ESBMC pode levar alguns segundos)..."

esbmc harness_calib.c     $C/calib.c     -I . -I $C --overflow-check                                 > "$O/1_calib_ESBMC.txt" 2>&1
esbmc harness_detection.c $C/detection.c -I . -I $C --unwind 35 --overflow-check                     > "$O/2_detection_ESBMC.txt" 2>&1
esbmc harness_filter.c    $C/filter.c    -I . -I $C --unwind 9 --overflow-check --no-unwinding-assertions > "$O/3_filter_ESBMC.txt" 2>&1
esbmc harness_calib_bug.c $C/calib.c     -I . -I $C --overflow-check                                 > "$O/4_calib_BUG_ESBMC.txt" 2>&1
cbmc  harness_calib.c     $C/calib.c     -I . -I $C --signed-overflow-check --bounds-check --div-by-zero-check > "$O/1_calib_CBMC.txt" 2>&1
cbmc  harness_detection.c $C/detection.c -I . -I $C --unwind 35 --signed-overflow-check --bounds-check         > "$O/2_detection_CBMC.txt" 2>&1
cbmc  harness_filter.c    $C/filter.c    -I . -I $C --unwind 9 --signed-overflow-check --bounds-check --div-by-zero-check > "$O/3_filter_CBMC.txt" 2>&1
cbmc  harness_calib_bug.c $C/calib.c     -I . -I $C --signed-overflow-check                          > "$O/4_calib_BUG_CBMC.txt" 2>&1

echo "==== RESUMO ===="
for f in "$O"/1_* "$O"/2_* "$O"/3_* "$O"/4_*; do
  r=$(grep -iE "VERIFICATION (SUCCESSFUL|FAILED)" "$f" | tail -1)
  printf "%-22s %s\n" "$(basename "$f" .txt)" "$r"
done | tee "$O/RESUMO.txt"
