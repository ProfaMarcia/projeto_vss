#include <assert.h>
#include "nondet.h"
#include "../src/core/detection.h"

int main(void){
    detector_t d; detector_init(&d, 300, 800, 50, 3);
    uint32_t n = nondet_uint32();
    ASSUME(n <= 30);
    for (uint32_t i = 0; i < n; i++){
        int32_t ppm = nondet_int32();
        ASSUME(ppm >= 0 && ppm <= 10000);
        gas_state_t s = detector_update(&d, ppm);
        assert(s == ST_NORMAL || s == ST_WARNING || s == ST_ALARM);
        assert(d.state <= ST_ALARM);
    }
    detector_t d2; detector_init(&d2, 300, 800, 50, 3);
    detector_update(&d2, 900);
    detector_update(&d2, 900);
    detector_update(&d2, 900);
    assert(d2.state == ST_ALARM);
    return 0;
}
