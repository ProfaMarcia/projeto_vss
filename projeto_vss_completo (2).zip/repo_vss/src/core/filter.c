#include "filter.h"
void filter_init(moving_avg_t *f){
    f->head = 0; f->count = 0; f->sum = 0;
    for (int i = 0; i < FILTER_WINDOW; i++) f->buf[i] = 0;
}
int32_t filter_push(moving_avg_t *f, int32_t x){
    if (f->count == FILTER_WINDOW) { f->sum -= f->buf[f->head]; }
    else { f->count++; }
    f->buf[f->head] = x;
    f->sum += x;
    f->head = (f->head + 1) % FILTER_WINDOW;
    return (int32_t)(f->sum / f->count);
}
