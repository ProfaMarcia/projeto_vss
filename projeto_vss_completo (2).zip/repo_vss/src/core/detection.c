#include "detection.h"
void detector_init(detector_t *d, int32_t warn, int32_t alarm, int32_t hyst, int32_t debounce_n){
    d->warn = warn; d->alarm = alarm; d->hyst = hyst;
    d->debounce_n = debounce_n; d->cnt = 0; d->state = ST_NORMAL;
}
gas_state_t detector_update(detector_t *d, int32_t ppm){
    if (ppm >= d->alarm) {
        if (d->cnt < d->debounce_n) d->cnt++;
        if (d->cnt >= d->debounce_n) d->state = ST_ALARM;
    } else if (ppm >= d->warn) {
        d->cnt = 0;
        if (d->state != ST_ALARM) d->state = ST_WARNING;
    } else if (ppm < (d->warn - d->hyst)) {
        d->cnt = 0; d->state = ST_NORMAL;
    }
    return d->state;
}
