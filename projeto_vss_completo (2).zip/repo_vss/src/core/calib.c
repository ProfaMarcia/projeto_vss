#include "calib.h"
int32_t calib_adc_to_ppm(int32_t raw) {
    int64_t ppm;
    if (raw < 0)        raw = 0;
    if (raw > ADC_MAX)  raw = ADC_MAX;
    ppm = ((int64_t)raw * (int64_t)PPM_MAX) / (int64_t)ADC_MAX;
    if (ppm < 0)        ppm = 0;
    if (ppm > PPM_MAX)  ppm = PPM_MAX;
    return (int32_t)ppm;
}
