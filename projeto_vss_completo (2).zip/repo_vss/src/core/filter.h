#ifndef FILTER_H
#define FILTER_H
#include <stdint.h>
#define FILTER_WINDOW 8
typedef struct {
    int32_t buf[FILTER_WINDOW];
    int32_t head, count;
    int64_t sum;
} moving_avg_t;
void filter_init(moving_avg_t *f);
int32_t filter_push(moving_avg_t *f, int32_t x);
#endif
