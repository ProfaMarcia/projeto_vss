#ifndef DETECTION_H
#define DETECTION_H
#include <stdint.h>
typedef enum { ST_NORMAL = 0, ST_WARNING = 1, ST_ALARM = 2 } gas_state_t;
typedef struct {
    int32_t warn, alarm, hyst;
    int32_t debounce_n, cnt;
    gas_state_t state;
} detector_t;
void detector_init(detector_t *d, int32_t warn, int32_t alarm, int32_t hyst, int32_t debounce_n);
gas_state_t detector_update(detector_t *d, int32_t ppm);
#endif
