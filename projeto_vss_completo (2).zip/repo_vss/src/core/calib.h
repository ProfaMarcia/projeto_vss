#ifndef CALIB_H
#define CALIB_H
#include <stdint.h>
#define ADC_MAX 4095
#define PPM_MAX 10000
int32_t calib_adc_to_ppm(int32_t raw);
#endif
